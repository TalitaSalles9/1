for (let i = 0; i <= 10; i++){
    console.log('O número atual é o ' + i)
}

//pode escrever for que o emmet auto completa.
