//Esse código imprime no console do navegador o texto "Olá mundo!" 
console.log("Olá mundo!")
