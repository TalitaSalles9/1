const boletoPago = false


if (boletoPago){
    console.log('O boleto está pago!')
}else if (boletoPago === false){
    console.log('O boleto não está pago!')
}

// boletoPago ? console.log('O boleto está pago!') : console.log('O boleto não está pago!')

