var x = 1;              //ESCOPO GLOBAL
var y = 3;              //ESCOPO GLOBAL
console.log(x, y);

function teste () {
    var z = 0;          //ESCOPO LOCAL
    console.log(z);
    console.log(x);
}
teste();

function testando(){
    var z = 5;           //ESCOPO LOCAL
    console.log(z);
}
testando();