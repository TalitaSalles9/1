const a = 2;
const b = 2;

console.log(!(a === b));




