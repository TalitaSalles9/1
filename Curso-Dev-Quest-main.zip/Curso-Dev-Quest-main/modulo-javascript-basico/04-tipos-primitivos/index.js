let nome = "Roberto"
let numero = 123
let usuarioVerificado = true 
let pessoa = null
let telefone = undefined

console.log(numero)