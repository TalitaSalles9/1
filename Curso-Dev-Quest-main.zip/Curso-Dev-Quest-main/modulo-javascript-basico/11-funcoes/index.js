/*
    function nomeDaFuncao(){
        <bloco de execucao>
    }
    nomeDaFuncao()

*/ 



function incentivarQuester(nomeQuester = 'Quester'){
    alert('Muito bem ' + nomeQuester + ', seu futuro será brilhante!')
}
incentivarQuester('Talita')





// function soma(numero1, numero2){
//     return numero1 + numero2
// }

// let resultadoDaSoma = soma(1, 3)
// console.log(resultadoDaSoma) //4

// resultadoDaSoma = soma(resultadoDaSoma, 10)
// console.log(resultadoDaSoma) //14

