// while (condicao){
//  <bloco de execução>
// }

let a = 10
let b = 15

while (a < b){
    console.log('incrementando a variável a' + a)
    a++;
}

// do{
//  <bloco de execução>
// }while(condição)

var i = 1
do {
    console.log('entrou ' + i)
    i++
}while(i <= 5)
