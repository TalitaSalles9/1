let nomeDoUsuario = prompt('Digite seu nome');
alert('Seja bem-vindo(a), ' + nomeDoUsuario + '!');








