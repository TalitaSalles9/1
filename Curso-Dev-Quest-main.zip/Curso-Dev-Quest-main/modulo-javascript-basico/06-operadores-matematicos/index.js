let primeiroValor = 4
let segundoValor = 2

console.log(primeiroValor + segundoValor)
console.log(primeiroValor - segundoValor)
console.log(primeiroValor / segundoValor)
console.log(primeiroValor * segundoValor)
console.log(primeiroValor % segundoValor)
