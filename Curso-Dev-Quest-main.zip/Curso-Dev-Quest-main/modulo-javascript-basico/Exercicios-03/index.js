const vaiSeHospedar = confirm('Seja bem vindo(a), voce gostaria de pagar R$ 50,00 para passar a noite na nossa hospedagem?')

if (vaiSeHospedar){
    alert('Ótimo! Nós temos as melhores camas de toda a região!')
}else{ // pode ser simples por ser um boolean
    alert('Que pena! Você parecia ser uma pessoa mais legal')
}



