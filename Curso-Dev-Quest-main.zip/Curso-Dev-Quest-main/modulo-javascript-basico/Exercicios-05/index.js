for (let index = 0; index <= 10; index++) {
    const dobroDoNumero = index * 2
    console.log('O dobro de ' + index + ' é ' + dobroDoNumero)
}

const soma = -5 + '-70'
console.log(soma)

