let nomeFilme = 'Vingadores'

if(nomeFilme === 'Vingadores'){
    console.log('é o filme dos vingadores')
}else if (nomeFilme === 'Batman vs Superman'){
     console.log('é o filme do batman vs superman')
}else{
    console.log('é outro filme')
}

true ? console.log('condição verdadeira') : console.log('condição falsa')

nomeFilme === 'Vingadores' ? console.log('é o filme dos vingadores') : console.log('é outro filme')

