// switch(parametro){ 
// case valor1:
//       <bloco de declaração>
//       break
// case valor2:
//      <bloco de declaração>
//       break
//}

// let nomeFilme = 'senhor dos aneis'

// switch(nomeFilme){
//     case 'Vingadores':
//         console.log('é o filme dos vingadores')
//         break
//     case 'Batman vs Superman':
//         console.log('é o filme do batman vs superman')
//         break
//     case 'Senhor dos aneis':
//         console.log('é o filme do Senhor dos aneis')
//         break
//     default:
//         console.log('é outro filme')
//         break
// }

let avaliacao = 1

switch (avaliacao){
    case 1:
    case 2:
        console.log('filme ruim')
        break
    case 3:
    case 4:
        console.log('filme mediano')
        break
    case 5: 
        console.log('filme excelente')
        break
    default:
        console.log('nota inválida')
        break
}
